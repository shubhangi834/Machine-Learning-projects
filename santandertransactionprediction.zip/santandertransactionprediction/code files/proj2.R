setwd("D:/edwisor/project 2/")
train <- read.csv("train.csv",header=T)
test <- read.csv("test.csv",header=T)

#DROPPING UNNECESSARY VARIABLES
train$ID_code <- NULL

#CONVERTING REQUIRED DATA TYPES
str(train)
str(test)
train$target <- as.factor(train$target)


#CHECKING MISSING VALUE
sum(is.na(train))
sum(is.na(test))   # no missing value found


#CHECKING TARGET CLASS IMBALANCE
table(train$target)


#DISTRIBUTION OF VARIABLES IN TRAIN DATA W.R.T TARGET CLASS
library(ggplot2)
for(i in names(train)[c(2:101)]){
  plot <- ggplot(train)+geom_density(aes(x=train[[i]],fill=target))+xlab(i)+theme_classic()
  print(plot)
}
for(i in names(train)[c(102:201)]){
  plot <- ggplot(train)+geom_density(aes(x=train[[i]],fill=target))+xlab(i)+theme_classic()
  print(plot)
}
#DISTRIBUTION OF VARIABLES IN TRAIN AND TEST DATA
for(i in names(train)[c(2:101)]){
  plot <- ggplot()+geom_density(data=train,aes(x=train[[i]]),kernel='gaussian',color='red')+
    theme_classic()+geom_density(data=test,aes(x=test[[i]]),kernel='gaussian',color='green')+xlab(i)
  print(plot)
}
for(i in names(train)[c(102:201)]){
  plot <- ggplot()+geom_density(data=train,aes(x=train[[i]]),kernel='gaussian',color='red')+
    theme_classic()+geom_density(data=test,aes(x=test[[i]]),kernel='gaussian',color='green')+xlab(i)
  print(plot)
}


#OUTLIER ANALYSIS
for(i in names(train)[c(2:201)]){
  val <- train[,i][train[,i] %in% boxplot.stats(train[,i])$out]
  train <- train[which(!train[,i] %in% val),]
}
for(i in names(test)[c(2:201)]){
  val <- test[,i][test[,i] %in% boxplot.stats(test[,i])$out]
  test <- test[which(!test[,i] %in% val),]
}


#CHECKING MULTICOLLINEARITY 
library(usdm)
vifcor(train[,-1],th=0.9)


#FEATURE ENGINEERING
library(moments)
train$mean <- apply(train[,2:201],1,mean)
train$median <- apply(train[,2:201],1,median)
train$minimum <- apply(train[,2:201],1,min)
train$maximum <- apply(train[,2:201],1,max)
train$stdeviation <- apply(train[,2:201],1,sd)
train$kurtosis <- apply(train[,2:201],1,kurtosis)
train$skewness <- apply(train[,2:201],1,skewness)
#normal distribution target wise
for(i in names(train)[c(202:208)]){
  plot <- ggplot(train)+geom_density(aes(x=train[[i]],fill=target))+xlab(i)+theme_classic()
  print(plot)
}

test$mean <- apply(test[,2:201],1,mean)
test$median <- apply(test[,2:201],1,median)
test$minimum <- apply(test[,2:201],1,min)
test$maximum <- apply(test[,2:201],1,max)
test$stdeviation <- apply(test[,2:201],1,sd)
test$kurtosis <- apply(test[,2:201],1,kurtosis)
test$skewness <- apply(test[,2:201],1,skewness)
#normal distribution in training and test data
for(i in names(train)[c(202:208)]){
  plot <- ggplot()+geom_density(data=train,aes(x=train[[i]]),kernel='gaussian',color='red')+
    theme_classic()+geom_density(data=test,aes(x=test[[i]]),kernel='gaussian',color='green')+xlab(i)
  print(plot)
}


#SPLITTING DATA IN TRAINING AND TEST
library(caret)
train.index <- createDataPartition(train$target,p=0.80,list=F)
train_df <- train[train.index,]
test_df <- train[-train.index,]
#TARGET BALANCING USING SMOTE
library(DMwR)
train_smote <- SMOTE(target~.,train_df,perc.over=600,perc.under=100)
#TARGET BALANCING USING ROSE
library(ROSE)
train_rose <- ROSE(target~.,data=train_df,seed=3)$data


#LOGISTIC REGRESSION

#using target class imbalance dataset
model_lr <- glm(target~.,data=train_df,family="binomial")
pred_lr <- predict(model_lr,newdata = test_df,type="response")
pred_lr <- ifelse(pred_lr>0.5,1,0)
table(test_df$target,pred_lr)
library(pROC)
target <- as.factor(test_df$target)
pred_lr <- as.numeric(pred_lr)
roc(response=target,predictor=pred_lr,auc=TRUE,plot=TRUE)
#using SMOTE
model_lr_s <- glm(target~.,data=train_smote,family="binomial")
pred_lr_s <- predict(model_lr_s,newdata = test_df,type="response")
pred_lr_s <- ifelse(pred_lr_s>0.5,1,0)
table(test_df$target,pred_lr_s)
pred_lr_s <- as.numeric(pred_lr_s)
roc(response=target,predictor=pred_lr_s,auc=TRUE,plot=TRUE)
#using ROSE
model_lr_r <- glm(target~.,data=train_rose,family="binomial")
pred_lr_r <- predict(model_lr_r,newdata = test_df,type="response")
pred_lr_r <- ifelse(pred_lr_r>0.5,1,0)
table(test_df$target,pred_lr_r)
pred_lr_r <- as.numeric(pred_lr_r)
roc(response=target,predictor=pred_lr_r,auc=TRUE,plot=TRUE)
#TUNING LR MODEL(ROSE)
set.seed(135)
control <- trainControl(method = "repeatedcv",number=10,repeats=3)
model <- train(target~.,data=train_rose,method="glm",family="binomial",trControl=control,tuneLength=5)
pred <- predict(model,newdata = test_df,type="raw")
pred <- ifelse(pred>0.5,1,0)
pred <- as.numeric(pred)
roc(response=target,predictor=pred,auc=TRUE,plot=TRUE)


#RANDOM FOREST

#with target class imbalance
library(randomForest)
model_rf <- randomForest(target~.,train_df,importance=TRUE,ntree=100)
pred_rf <- predict(model_rf,test_df[,-1])
table(test_df$target,pred_rf)
pred_rf <- as.numeric(pred_rf)
roc(response=target,predictor=pred_rf,auc=TRUE,plot=TRUE)
#using SMOTE
model_rf_s <- randomForest(target~.,train_smote,importance=TRUE,ntree=100)
pred_rf_s <- predict(model_rf_s,test_df[,-1])
table(test_df$target,pred_rf_s)
pred_rf_s <- as.numeric(pred_rf_s)
roc(response=target,predictor=pred_rf_s,auc=TRUE,plot=TRUE)
#using ROSE
model_rf_r <- randomForest(target~.,train_rose,importance=TRUE,ntree=100)
pred_rf_r <- predict(model_rf_r,test_df[,-1])
table(test_df$target,pred_rf_r)
pred_rf_r <- as.numeric(pred_rf_r)
roc(response=target,predictor=pred_rf_r,auc=TRUE,plot=TRUE)

#checking important variables
importance(model_rf,type=2)

#plotting PDP for important variables using random forest model
df <- train_df[,c(2,3,4,8,11,14,15,17,20,21,24,25,28,42,46,55,58,77,78,80,82,83,87,93,94,97,99,101,108,110,111,112,148,151,157,165,166,167,168,176,182,192,194,199,200)]
library(pdp)
for(i in names(df)){
  par.i <- partial(model_rf,pred.var=c(i),chull=TRUE)  
  plot.i <- autoplot(par.i,contour=TRUE)
  print(plot.i)
}

#NAIVE BAYES

#with target class imbalance
library(e1071)
model_nb <- naiveBayes(target~.,data=train_df)
pred_nb <- predict(model_nb,test_df[,-1],type='class')
table(test_df$target,pred_nb)
pred_nb <- as.numeric(pred_nb)
roc(response=target,predictor=pred_nb,auc=TRUE,plot=TRUE)
#using SMOTE
model_nb_s <- naiveBayes(target~.,data=train_smote)
pred_nb_s <- predict(model_nb_s,test_df[,-1],type='class')
table(test_df$target,pred_nb_s)
pred_nb_s <- as.numeric(pred_nb_s)
roc(response=target,predictor=pred_nb_s,auc=TRUE,plot=TRUE)
#using ROSE
model_nb_r <- naiveBayes(target~.,data=train_rose)
pred_nb_r <- predict(model_nb_r,test_df[,-1],type='class')
table(test_df$target,pred_nb_r)
pred_nb_r <- as.numeric(pred_nb_r)
roc(response=target,predictor=pred_nb_r,auc=TRUE,plot=TRUE)


#XGBOOST
library(xgboost)
#using target class imbalance
set.seed(100)
train_df$target <- as.numeric(train_df$target)
for(i in 1:nrow(train_df)){
      train_df$target[i] <- ifelse(train_df$target[i]==1,0,1)
 }
model_xgb <- xgboost(data=data.matrix(train_df[,-1]),label = train_df$target,eta=1,max_depth=16,nrounds = 25,objective="binary:logistic")
pred_xgb <- predict(model_xgb,data.matrix(test_df[,-1]))
pred_xgb <- ifelse(pred_xgb>0.5,1,0)
table(test_df$target,pred_xgb)
pred_xgb <- as.numeric(pred_xgb)
roc(response=target,predictor=pred_xgb,auc=TRUE,plot=TRUE)
#using SMOTE
train_smote$target <- as.numeric(train_smote$target)
for(i in 1:nrow(train_smote)){
  train_smote$target[i] <- ifelse(train_smote$target[i]==1,0,1)
}
model_xgb_s <- xgboost(data=data.matrix(train_smote[,-1]),label = train_smote$target,eta=1,max_depth=16,nrounds = 25,objective="binary:logistic")
pred_xgb_s <- predict(model_xgb_s,data.matrix(test_df[,-1]))
pred_xgb_s <- ifelse(pred_xgb_s>0.5,1,0)
table(test_df$target,pred_xgb_s)
pred_xgb_s <- as.numeric(pred_xgb_s)
roc(response=target,predictor=pred_xgb_s,auc=TRUE,plot=TRUE)
#using ROSE
train_rose$target <- as.numeric(train_rose$target)
for(i in 1:nrow(train_rose)){
  train_rose$target[i] <- ifelse(train_rose$target[i]==1,0,1)
}
model_xgb_r <- xgboost(data=data.matrix(train_rose[,-1]),label = train_rose$target,eta=1,max_depth=16,nrounds = 25,objective="binary:logistic")
pred_xgb_r <- predict(model_xgb_r,data.matrix(test_df[,-1]))
pred_xgb_r <- ifelse(pred_xgb_r>0.5,1,0)
table(test_df$target,pred_xgb_r)
pred_xgb_r <- as.numeric(pred_xgb_r)
roc(response=target,predictor=pred_xgb_r,auc=TRUE,plot=TRUE)

#checking important variables through xgboost
importance=xgb.importance(feature_names = names(data.matrix(train_df[,-1])),model=model_xgb)
xgb.plot.importance(importance_matrix = importance)


#KNN

#normalisation
for(i in names(train_df)[c(2:208)]){
  train_df[,i] <- (train_df[,i]-min(train_df[,i]))/(max(train_df[,i])-min(train_df[,i]))
}
for(i in names(test_df)[c(2:208)]){
  test_df[,i]=(test_df[,i]-min(test_df[,i]))/(max(test_df[,i])-min(test_df[,i]))
}
#using target class imbalance
library(class)
train_df$target <- as.factor(train_df$target)
pred_knn <- knn(train_df[,2:208],test_df[,2:208],train_df$target,k=1)
table(test_df$target,pred_knn)
pred_knn <- as.numeric(pred_knn)
roc(response=target,predictor=pred_knn,auc=TRUE,plot=TRUE)
#using SMOTE
train_smote$target <- as.factor(train_smote$target)
for(i in names(train_smote)[c(2:208)]){
  train_smote[,i] <- (train_smote[,i]-min(train_smote[,i]))/(max(train_smote[,i])-min(train_smote[,i]))
}
pred_knn_s <- knn(train_smote[,2:208],test_df[,2:208],train_smote$target,k=1)
table(test_df$target,pred_knn_s)
pred_knn_s <- as.numeric(pred_knn_s)
roc(response=target,predictor=pred_knn_s,auc=TRUE,plot=TRUE)
#using ROSE
train_rose$target <- as.factor(train_rose$target)
for(i in names(train_rose)[c(2:208)]){
  train_rose[,i] <- (train_rose[,i]-min(train_rose[,i]))/(max(train_rose[,i])-min(train_rose[,i]))
}
pred_knn_r <- knn(train_rose[,2:208],test_df[,2:208],train_rose$target,k=1)
table(test_df$target,pred_knn_r)
pred_knn_r <- as.numeric(pred_knn_r)
roc(response=target,predictor=pred_knn_r,auc=TRUE,plot=TRUE)



#Final prediction on test data
predictions <- predict(model_lr_r,newdata = test,type="response")
predictions <- ifelse(predictions>0.5,1,0)
predictions <- as.data.frame(predictions)
a <- test[,1]
final_predictions <- cbind(a,predictions)



