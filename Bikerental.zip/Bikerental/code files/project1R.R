rm(list=ls())
setwd("D:/edwisor/project1/")
data=read.csv("day.csv",header=T)


#REMOVING UNNECESSARY VARIABLES
data$instant=NULL
data$dteday=NULL
data$casual=NULL
data$registered=NULL


#CONVERTING REQUIRED DATA TYPES
str(data)
data$instant=as.numeric(data$instant)
data$casual=as.numeric(data$casual)
data$registered=as.numeric(data$registered)
data$cnt=as.numeric(data$cnt)
for(i in 1:ncol(data)){
  if(class(data[,i])=='integer'){
    data[,i]=as.factor(data[,i])
  }
}

#CHECKING MISSING VALUE
sum(is.na(data))
#no missing value in this data


##FEATURE SELECTION
numeric_index=sapply(data,is.numeric)
num_data=data[,numeric_index]         #separating numeric and categorical variables

#scatter plot to see how much target variable is dependent on independent numeric variables
u=c("temp","atemp","hum","windspeed")
library(ggplot2)
for(i in 1:length(u)){
  assign(paste0("SP",i),ggplot(data,aes_string(x=u[i],y=data$cnt))+
           geom_point(size=4)+xlab("cnt")+ylab(u[i]))
}
gridExtra::grid.arrange(SP1,SP2,ncol=2)
gridExtra::grid.arrange(SP3,SP4,ncol=2)

#correlation plot for numerical variables
library(corrgram)
corrgram(num_data,order=F,upper.panel=panel.pie,text.panel=panel.txt,main="correlation plot")

#checking multicollinearity using correlation coefficient
library(usdm)
for(i in 1:ncol(data)){
       if(class(data[,i])=='factor'){
            data[,i]=as.numeric(data[,i])
        }
   }
vifcor(data[,-11],th=0.9)

#dropping variable 'atemp'because of multicollinearity problem
data$atemp=NULL     


##OUTLIER ANALYSIS

#plotting histogram for numeric variables
num_data$atemp=NULL
cnames=names(num_data)
for(i in 1:length(cnames)){
  assign(paste0("histogram",i),ggplot(num_data,aes_string(x=cnames[i]))+
           geom_histogram(fill="cornsilk",colour="black")+geom_density()+
           xlab(cnames[i])+ylab("frequency"))
}
gridExtra::grid.arrange(histogram1,histogram2,ncol=2)
gridExtra::grid.arrange(histogram3,histogram4,ncol=2)

#creating boxplots for numerical variable
boxplot(data$cnt)
boxplot(data$hum)   #outliers found
boxplot(data$windspeed)   #outliers found
boxplot(data$temp)

#replacing outliers with NA
cnames=c("cnt","hum","windspeed","temp")
for(i in cnames){
val=data[,i][data[,i] %in% boxplot.stats(data[,i])$out]
data[,i][data[,i] %in% val]=NA
}
sum(is.na(data)) #15
missing_value=data.frame(apply(data,2,function(x){sum(is.na(x))}))

#checking correct method
#KNN
df=data    #copying data
df[76,9] #0.602917
df[76,10]   #0.2095790
df[76,9]=NA    
df[76,10]=NA
library(DMwR)
df=knnImputation(df,k=5)
df[76,9]   #0.475079
df[76,10] #0.2272439
#MEAN
rm(df)
df=data    #reload data again
df[76,9]=NA
df[76,10]=NA
df$hum[is.na(df$hum)]=mean(df$hum,na.rm=T)
df$windspeed[is.na(df$windspeed)]=mean(df$windspeed,na.rm=T)
df[76,9]    #0.6293952
df[76,10]   #0.1863595
#MEDIAN
rm(df)
df=data     #reload data again
df[76,9]=NA
df[76,10]=NA
df$hum[is.na(df$hum)]=median(df$hum,na.rm=T)
df$windspeed[is.na(df$windspeed)]=median(df$windspeed,na.rm=T)
df[76,9]      #0.6283335
df[76,10]     #0.178496

#imputing missing values in our data with MEAN method
rm(df)
data$hum[is.na(data$hum)]=mean(data$hum,na.rm=T)
data$windspeed[is.na(data$windspeed)]=mean(data$windspeed,na.rm=T)

#checking if outliers still present
boxplot(data$hum)    #no outlier found
boxplot(data$windspeed)     #outlier found
val_2=data$windspeed[data$windspeed %in% boxplot.stats(data$windspeed)$out]
data$windspeed[data$windspeed %in% val_2]=NA
data$windspeed[is.na(data$windspeed)]=mean(data$windspeed,na.rm=T)
boxplot(data$windspeed)    #no outliers


#SELECTING SUITABLE MACHINE LEARNING ALGORITHM
train.index=sample(1:nrow(data),0.8*nrow(data))
train=data[train.index,]
test=data[-train.index,]
mape=function(y,yhat){
  mean(abs((y-yhat)/y))*100
}
mae=function(y,yhat){
       mean(abs(y-yhat))
}
rmse=function(y,yhat){
  sqrt(mean((y-yhat)^2))
}

#Decision tree regression
library(rpart)
dt_model=rpart(cnt~.,data=train,method="anova")
dt_predictions=predict(dt_model,test[,-11])
mape(test[,11],dt_predictions)  # mean absolute percentage errror=17.30875%
mae(test[,11],dt_predictions)   #mean absolute error=679.0181
rmse(test[,11],dt_predictions)  #root mean square error=871.9282

#Random Forest Regression
library(randomForest)
library(inTrees)
rf_model=randomForest(cnt~.,train,importance=TRUE,ntree=100)
list=RF2List(rf_model)
rules=extractRules(list,train[,-11])
rulemetric=getRuleMetric(rules,train[,-11],train$cnt)
rf_predictions=predict(rf_model,test[,-11])
mape(test[,11],rf_predictions)   #mean absolute percentage error=11.20957%
mae(test[,11],rf_predictions)    #mean absolute error=435.41
rmse(test[,11],rf_predictions)   #root mean square error=598.1497
#WHEN NO. OF TREES=200,   mape=11.21%, mae=432.6389, rmse=581.2985
#WHEN NO. OF TREES=500,   mape=10.87%, mae=421.9665, rmse=573.3131

#Linear Regression
lr_model=lm(cnt~.,data=train)
summary(lr_model)                 #R-squared=79.07% , adjusted R-squared=78.7%
lr_predictions=predict(lr_model,test[,-11])
mape(test[,11],lr_predictions)    #mean absolute percentage error=14.54468%
mae(test[,11],lr_predictions)     #mean absolute error=600.6899
rmse(test[,11],lr_predictions)    #root mean square error=797.2005

#KNN
library(caret)
knn_model=knnreg(train[,-11],train[,11],k=1)
knn_predictions=predict(knn_model,test[,-11])
mape(test[,11],knn_predictions)   #mean absolute percentage error=19.99%
mae(test[,11],knn_predictions)    #mean absolute error=768.6531
rmse(test[,11],knn_predictions)   #root mean square error=1035.582
#WHEN NEAREST NEIGHBORS=3,   mape=16.09%, mae=646.246, rmse=874.9245
#WHEN NEAREST NEIGHBORS=5,   mape=15.83%, mae=651.4027, rmse=865.7673
#WHEN NEAREST NEIGHBORS=7,   mape=16.18%, mae=671.4837, rmse=900.8684
